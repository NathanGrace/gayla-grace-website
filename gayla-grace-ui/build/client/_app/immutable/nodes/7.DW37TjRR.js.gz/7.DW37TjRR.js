import{f as p,a as r}from"../chunks/D5J7uzp-.js";import"../chunks/CeH4aLRe.js";var t=p("<h1>Speaking Page</h1>");function n(a){var o=t();r(a,o)}export{n as component};
