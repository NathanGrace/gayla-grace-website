import{f as r,a as t}from"../chunks/D5J7uzp-.js";import"../chunks/CeH4aLRe.js";var p=r("<h1>About Page</h1>");function n(o){var a=p();t(o,a)}export{n as component};
