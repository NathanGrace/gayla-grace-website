import{f as a,a as e}from"../chunks/D5J7uzp-.js";import"../chunks/CeH4aLRe.js";var p=a("<h1>Free Resourrces Page</h1>");function n(o){var r=p();e(o,r)}export{n as component};
