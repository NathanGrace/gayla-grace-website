import{f as t,a as r}from"../chunks/D5J7uzp-.js";import"../chunks/CeH4aLRe.js";var p=t("<h1>Contact Page</h1>");function e(o){var a=p();r(o,a)}export{e as component};
