import{f as r,a as p}from"../chunks/D5J7uzp-.js";import"../chunks/CeH4aLRe.js";var t=r("<h1>Books Page</h1>");function n(o){var a=t();p(o,a)}export{n as component};
